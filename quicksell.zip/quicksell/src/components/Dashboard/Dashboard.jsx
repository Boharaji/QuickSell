import React from 'react'
import './dashboard.css'

const Dashboard = () => {
    return (
        <div className='dash-container'>
            Dashboard
        </div>
    )
}

export default Dashboard